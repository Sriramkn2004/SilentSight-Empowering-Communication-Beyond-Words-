from django.contrib import admin
from .models import imagefield
from .models import audiofield

admin.site.register(imagefield)
admin.site.register(audiofield)

